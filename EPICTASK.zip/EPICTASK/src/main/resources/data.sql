INSERT INTO users (name, email, pass) VALUES
('Joao Carlos', 'joao@gmail.com', 'o8seis*&ûshfs9');

INSERT INTO tasks (title, description, point, status) VALUES
('Criação de tasks', 'CRUD de task', 50, 20);
INSERT INTO tasks (title, description, point, status) VALUES
('Teste', 'Teste de task', 10, 90);